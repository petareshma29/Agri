AGRIRAKSHA - UPDATED LIVE SERVER EDITION

Run:
1. Extract the ZIP.
2. Open the Agri folder in VS Code.
3. Open index.html with Live Server (Go Live).

Changes made:
- Existing Home page layout/content retained; only a small English/తెలుగు language selector was added.
- Farmer Login now opens a dedicated page.
- Farmer verification supports Phone, Aadhaar and Email.
- Demo OTP is generated on the page because this project is static and has no SMS/email gateway.
- Verified farmer opens a personal Farmer Dashboard.
- Admin Login opens a dedicated Admin Login page.
- Admin Dashboard includes farmer management, crop monitoring and alerts.
- English/తెలుగు selector works on login and dashboard pages and is remembered with localStorage.
- Existing farmer images, soil, weather and crop-rate pages are retained.

DEMO FARMER:
Phone: 9876543210
Aadhaar: 123456789012
Email: ramesh@agriraksha.demo
OTP: generated after clicking Send OTP and displayed in the demo page.

SECOND DEMO FARMER:
Phone: 9123456780
Aadhaar: 234567890123
Email: sita@agriraksha.demo

DEMO ADMIN:
Email: admin@agriraksha.demo
Password: Admin@123

Important:
The farmer records included in this static demo are sample records because the uploaded project did not contain a database/backend with real farmer accounts. Replace data.js with your real data/backend later.
Real SMS/email OTP requires a backend and an SMS/email provider; this Live Server version uses a displayed demo OTP instead.
